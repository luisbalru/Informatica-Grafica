#include "Objeto3D.hpp"

string Objeto3D::nombre()
{
  return nombre_obj;
}
