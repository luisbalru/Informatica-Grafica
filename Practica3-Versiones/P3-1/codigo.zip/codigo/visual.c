/*

	C.A.D. 						Curso 2004-2005
	
	Dpto. Lenguajes y Sistemas Informaticos
	E.T.S.I. Informaica
	Univ. de Granada

        Modulo de transformacion de visualizacion del proyecto grua
	

*/


/* %%  Poner dos modelos de camara: orto con desplazamiento y zoom
y perpsectiva, simulando una persona que se mueve por el escenario
con desplazamiento sobre el plano, levitacion y giro X e Y.
*/
#include <GL/glut.h>
#define  __visual__
#include "visual.h"






/** 

Fija la transformacion de visualizacion en funcion de los angulos de rotacion view_rotx,
view_roty y view_rotz y el desplazamiento de la camara d.

**/ 
void transformacionVisualizacion()
{

if(VISTA_PERSPECTIVA){
 // 	glTranslatef(0,0,-d);

// Colocar aqui la luz si esta fija respecto del observador
    	glTranslatef(0,0,-1.5);
 	
 	glRotatef( view_rotx, 1.0, 0.0, 0.0 );
   	glRotatef( view_roty, 0.0, 1.0, 0.0 );
//   	glRotatef( view_rotz, 0.0, 0.0, 1.0 );
	
	glTranslatef(-x_camara,-y_camara,-z_camara);
	}
  else 	
  	{
	glTranslatef(-origenXVentanaMundoParalelo,-origenYVentanaMundoParalelo,-40);
   	glRotatef(90,1,0,0);        //@ Transf. para colocar camara arriba
	}
}

/**

Fija la transformacion de proyeccion. 

**/
void fijaProyeccion()
{
	float calto; 	// altura de la ventana corregida
	
  	if(anchoVentana>0)
  		calto = altoVentana/anchoVentana;
  	else
  		calto = 1;
if(VISTA_PERSPECTIVA)	glFrustum(-1,1,-calto,calto,1.5,1500);
else 			glOrtho(-ventanaMundoParalela/2, ventanaMundoParalela/2, -ventanaMundoParalela*calto/2, ventanaMundoParalela*calto/2,2,1000);
// A partir de este momento las transformaciones son de modelado.	
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
//  transformacionVisualizacion();
  
}


/**

Inicializa el viewport para que ocupe toda la ventana X, y llama a fijaProyeccion.

**/

void inicializaVentana(GLsizei ancho,GLsizei alto)
{
	altoVentana=alto;
	anchoVentana=ancho;

  // Establecemos el Viewport usando la nueva anchura y altura de la ventana X
  	glViewport(0,0,ancho,alto);

 // Especificamos la transformacion� de visualizacion.	
  	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	
	fijaProyeccion();

}


