/*

	C.A.D. 						Curso 2006-2007
	
	Dpto. Lenguajes y Sistemas Inform�icos
	E.T.S.I. Inform�ica
	Univ. de Granada

        Grua 1


*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "glui.h"
#include "estructura.h"
#include "entradaTeclado.h"
#include "entradaMenu.h"
#include "visual.h"
#include "mouse.h"
#include "modelo.h"
#include "iu.h"



/*=================================================*/ 



int main( int argc, char *argv[] )
{
// Inicializa glu y Mesa
   glutInit( &argc, argv );

// Crea una ventana X para la salida gr�ica
   glutInitWindowPosition( 0, 0 );
   glutInitWindowSize( 600, 600 );
   glutInitDisplayMode( GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH );
   gluiCreateWindow("CAD. Curso 2006/07");

      initModel();
    creaIU();
// Inicializa las funciones de dibujo y cambio de tamanyo� de la ventana X
   glutDisplayFunc( Dibuja );
   glutReshapeFunc( inicializaVentana );

// FUNCIONES DE INTERACCI�
  
   glutKeyboardFunc(letra);
   glutSpecialFunc(especial);
   
   glutMouseFunc( clickRaton );
   glutMotionFunc( RatonMovido );
   glutTimerFunc(200,idle,0);
    CreaMenu();
   
   glEnable(GL_DEPTH_TEST);
   glEnable(GL_CULL_FACE);
   glEnable( GL_LIGHTING );
   glEnable( GL_LIGHT0 );

   glutMainLoop();
   return 0;
}
