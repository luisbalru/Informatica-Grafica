/*

	C.A.D. 						Curso 2006-2007
	
	Dpto. Lenguajes y Sistemas Informaticos
	E.T.S.I. Informaica
	Univ. de Granada

        Fichero de cabecera para el modulo de creacion del modelo de la grua
	

*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <GL/glut.h>

#ifndef __modeloH__ // Para evitar doble inclusion
#define __modeloH__



#ifndef __modelo__ // No esta compilando modelo

#define ambito extern

#else // Esta compilando  modelo

#define ambito

#endif

/**
Definicion de identificadores de colores. Los valores se corresponden con la
posicion en la matriz color.
**/
#define amarillo 0
#define gris 1
#define rojo 2
#define	marron 3
#define celeste 4
#define naranja 5
#define verde 6
#define colorfeedback 7
#define azul 8
#define violeta 7

// +++++++++++++++++++++++++++++++++++++++++

#define MAXNAMES 10
#define MAXOBJETOS 10

#define NGruas 20
#define NCajones 50

ambito int COLORGRUA;



ambito float color[9][4];


// void pick(int x, int y);


void Dibuja( void );

void idle();

void initModel();


#endif
#undef ambito
