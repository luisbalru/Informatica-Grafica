/*

	C.A.D. 						Curso 2006-2007
	
	Dpto. Lenguajes y Sistemas Informaticos
	E.T.S.I. Informaica
	Univ. de Granada

        Fichero de cabecera del modulo de entrada de menu del proyecto grua
	

*/

// Nota: Los acentos han sido suprimidos en la documentacion por compatibilidad
// con las version usada de doxygen. Las letras ñ se han sustituido por "ny"

// ----------------------- Datos para menus

// ---
#ifndef __entradaMenuH__ // Para evitar doble inclusion
#define __entradaMenuH__

#ifndef __entradaMenu__ // No esta compilando entradaMenu

#define ambito extern

#else // Esta compilando  entradaMenu

#define ambito

#endif

typedef enum {neutro, seleccionandoGrua,seleccionandoCaja,
	PintandoCajas,gruaSeleccionada,paseando,vistaArriba} ESTADO;


typedef enum{ SALIR,ENGANCHAR, DESENGANCHAR, ROTARCAJA, MOVERCAJA,
	PONERCAJAS, DESDEARRIBA, OPERARGRUA, PASEAR, PINTARCAJA
	} opciones_menu;  	// Ident. de opciones del menu


void seleccionMenu( int opcion );
// Este procedimiento es llamado por el sistema cuando se selecciona una
// opcion del menu glut. El parametro contiene el identificador de la opcion

 
void CreaMenu();
// Este proc. se usa para definir el menu glut. Se llama desde main.


ambito int estadoMenu;

ambito  int	menu;     // Identificador del menu glut



#endif
#undef ambito

