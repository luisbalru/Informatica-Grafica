/*

	C.A.D. 						Curso 2006-2007
	
	Dpto. Lenguajes y Sistemas Informaticos
	E.T.S.I. Informaica
	Univ. de Granada

        Modulo de entrada de teclado del proyecto grua
	

*/

#include <stdio.h>
#include <stdlib.h>
#include <GL/glut.h>                   // Libreria de utilidades de OpenGL
#include "entradaMenu.h"
#include "visual.h"
#include "modelo.h"

/** 

Imprime en la consola las instrucciones del programa

**/
void printHelp(){
  	
	printf("\n\n                        C.A.D. 		Curso 2006-2007");
  	printf("\n\n Dpto. Lenguajes y Sistemas Informaticos");
  	printf("\n E.T.S.I. Informatica		Univ. de Granada ");
  	printf("\n");
        printf("\n Opciones: \n\n");
  	printf("h, H: Imprime informacion de ayuda \n");
  	printf("b,B: Hace que gire el brazo de la grua\n");
  	printf("a: Detiene el brazo de la grua\n");
  	printf("p,P: Desplaza la pluma sobre el brazo\n");
  	printf("o: Detiene la pluma\n");
  	printf("g,G: Sube y baja el gancho\n");
  	printf("f: Detiene el gancho\n");
  	printf("\n");
	
  	printf("2: Camara con proyeccion paralela mirando desde arriba \n");
  	printf("	En este modo:\n");
  	printf("	+,-: zoom\n");
  	printf("	x,X,z,Z: mueven la camara\n\n");
  	printf("3: Camara perspectiva moviendose por el escenario \n");
  	printf("	En este modo:\n");
  	printf("	x,X,z,Z: mueven la camara\n\n");
	printf("	PgUp, PgDn: mueven la camara hacia delante / atras \n\n");
  	printf("	Teclas de movimiento de cursor: giran la camara\n");
        printf("\n Boton derecho del raton activa el menu");
 
 // Anyade la informacion de las opciones que introduzcas aqui !! 	
	
	printf("\n Escape: Salir");
  	printf("\n\n\n");
}




/* @teclado ---------------------------------------------------------------- */

/**

Este procedimiento es llamado por el sistema cuando se pulsa una tecla normal
El codigo k es el ascii de la letra

Para anyadir nuevas ordenes de teclado coloca el correspondiente case.

Parametros de entrada:

k: codigo del caracter pulsado

x:

y:

**/

void letra (unsigned char k, int x, int y)
{
  switch (k) {
  case 'h':
  case 'H':
           printHelp(); // H y h imprimen ayuda
  	break;
  case 'z':
     if(VISTA_PERSPECTIVA) z_camara -= 5.0;   //
     else origenYVentanaMundoParalelo-=5;
    break;
  case '+':             // + Camara mas cerca
    if(ventanaMundoParalela>10) ventanaMundoParalela = ventanaMundoParalela*0.75;
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    fijaProyeccion();
    break;
  case '-':             // - Camara mas lejos
    ventanaMundoParalela =ventanaMundoParalela* 1.25;
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    fijaProyeccion();
    break;
  case 'Z':
    if(VISTA_PERSPECTIVA) z_camara += 5.0;   // 
    else origenYVentanaMundoParalelo+=5;
    break;
  case 'x':
     if(VISTA_PERSPECTIVA) x_camara -= 5.0;   // 
     else origenXVentanaMundoParalelo-=5;
    break;
  case 'X':
     if(VISTA_PERSPECTIVA) x_camara += 5.0;   // 
     else origenXVentanaMundoParalelo+=5;
    break;
case '3':
	VISTA_PERSPECTIVA= 1; 
	estadoMenu= paseando;
	glMatrixMode(GL_PROJECTION);
    	glLoadIdentity();
	fijaProyeccion();
	break;
case '2':
	VISTA_PERSPECTIVA= 0;
	glMatrixMode(GL_PROJECTION);
    	glLoadIdentity();
	fijaProyeccion();
	break;
// ----    
  case 27:  // Escape  Terminar
    exit(0);
    break;  
  default:
    return;
  }
  
glutPostRedisplay();  // Algunas de las opciones cambian paramentros
}                       // de la camara. Es necesario actualziar la imagen

/**
Este procedimiento es llamado por el sistema cuando se pulsa una tecla
especial. El codigo k esta definido en glut mediante constantes

Parametros de entrada:

k: codigo del caracter pulsado (definido en glut mediante constantes).

x:

y:

**/
void especial(int k, int x, int y)

{
  switch (k) {
  case GLUT_KEY_UP:
    view_rotx += 5.0;   // Cursor arriba + rotacion x
    break;
  case GLUT_KEY_DOWN:
    view_rotx -= 5.0;
    break;
  case GLUT_KEY_LEFT:
    view_roty += 5.0;
    if(view_roty>360) view_roty-=360;
    break;
  case GLUT_KEY_RIGHT:
    view_roty -= 5.0;
    if(view_roty<0) view_roty+=360;
    break;

  case GLUT_KEY_PAGE_DOWN:  
     x_camara+=-sin(3.14159*view_roty/180.0);
     z_camara+= cos(3.14159*view_roty/180.0);
     break;
  case GLUT_KEY_PAGE_UP:
     x_camara+= sin(3.14159*view_roty/180.0);
     z_camara+=-cos(3.14159*view_roty/180.0);
     break;

  default:
    return;
  }
   glutPostRedisplay();  // Actualiza la imagen (ver proc. letra)
}
 
