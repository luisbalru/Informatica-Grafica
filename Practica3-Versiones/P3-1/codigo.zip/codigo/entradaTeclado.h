/*

	C.A.D. 						Curso 2004-2005
	
	Dpto. Lenguajes y Sistemas Informaticos
	E.T.S.I. Informaica
	Univ. de Granada

        Fichero de cabecera para el modulo de entrada de teclado del proyecto grua
	

*/


void letra (unsigned char k, int x, int y);
// Este procedimiento es llamado por el sistema cuando se pulsa una tecla normal
// El codigo k es el ascii de la letra

void especial(int k, int x, int y);
// Este procedimiento es llamado por el sistema cuando se pulsa una tecla
// especial. El codigo k esta definido en glut mediante constantes
