
/*

	C.A.D. 						Curso 2006-2007
	
	Dpto. Lenguajes y Sistemas Informaticos
	E.T.S.I. Informaica
	Univ. de Granada

        Fichero de cabecera del modulo de transformacion de visualizacion del proyecto grua
	

*/
#ifndef __iuH__ // Para evitar doble inclusion
#define __iuH__



#ifndef __iu__ // No esta compilando modelo

#define ambito extern

#else // Esta compilando  modelo

#define ambito

#endif

ambito int colorActivo;

void  creaIU();

void DrawBoton();

void pulsadoBoton();

void drawSeleccionColor();

void DrawNaranja();

void colorNaranja();

void entrada ( unsigned char *name);

void DrawPalancas();

void seleccionaPalancas( int boton, int estado, int x, int y);

void muevePalanca( int x, int y);




void seleccionColor( int boton, int estado, int x, int y);
#endif
#undef ambito
