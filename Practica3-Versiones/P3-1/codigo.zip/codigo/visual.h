
/*

	C.A.D. 						Curso 2004-2005
	
	Dpto. Lenguajes y Sistemas Informaticos
	E.T.S.I. Informaica
	Univ. de Granada

        Fichero de cabecera del modulo de transformacion de visualizacion del proyecto grua
	

*/
#ifndef __visualH__ // Para evitar doble inclusion
#define __visualH__



#ifndef __visual__ // No esta compilando modelo

#define ambito extern

#else // Esta compilando  modelo

#define ambito

#endif


/**

Angulos de rotacion de la camara.

**/

ambito float view_rotx, view_roty, view_rotz;

/**

Indica el tipo de proyeccion que se esta realizando. Si esta a uno 
se hace proyeccion perspectiva, en caso contrario se hace paralela.

**/
ambito int VISTA_PERSPECTIVA;

/**

Tamanyo para la ventana del mundo en proyeccion paralela.

**/
ambito float ventanaMundoParalela;

/**

Coordenadas x,y de la esquina inferior de la ventana del mundo en vista
paralela.
 
**/
ambito float origenXVentanaMundoParalelo;
ambito float origenYVentanaMundoParalelo;

/**

Distancia de la camara al centro de coordenadas del modelo.

**/
ambito float d;

ambito float x_camara,y_camara,z_camara;

ambito float anchoVentana,altoVentana;

void fijaProyeccion();

void transformacionVisualizacion();


void inicializaVentana(GLsizei ancho,GLsizei alto);

#endif
#undef ambito
