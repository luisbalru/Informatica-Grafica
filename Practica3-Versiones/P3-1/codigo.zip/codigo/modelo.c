/*

	C.A.D. 						Curso 2006-2007
	
	Dpto. Lenguajes y Sistemas Informaticos
	E.T.S.I. Informaica
	Univ. de Granada

        Modulo de creacion del modelo de la grua
	

*/

#define __modelo__ 

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <GL/glut.h>
#include "estructura.h"
#include "entradaTeclado.h"
#include "entradaMenu.h"
#include "visual.h"
#include "mouse.h"
#include "iu.h"

#include "modelo.h"



int COLORGRUA=0;


/**

Inicializa el modelo.

**/

void initModel()
{
/**
Definicion de los colores usados.
**/
float colores[9][4]={{1,1,0,1.},{0.7,0.7,0.7,1},{1.0,0.3,0.3,1},
   		   {0.7,0.6,0.2,1},{0.2,1.0,1.0,1},{1.0,0.86,0.3,1},
		   {0.4,1,0.4,1.},{1,0.6,1,1.},{0,0,1,1.}};
int i,j;
	for(i=0;i<4;++i)
		for(j=0;j<9;++j)
			color[j][i]=colores[j][i];

	COLORGRUA=0;

	view_rotx=-30.0;
	view_roty=-45.0;
	view_rotz=0.0;
	d=100.0;

	x_camara=20;
	y_camara=2;
	z_camara=20;

	VISTA_PERSPECTIVA=0;

	ventanaMundoParalela=200;
	origenXVentanaMundoParalelo=0;
	origenYVentanaMundoParalelo=0;

	colorActivo=0;
}

/**
Procedimiento de dibujo del modelo. Es llamado por glut cada vez que se debe redibujar.
**/

void Dibuja( void )
{
   static GLfloat pos[4] = {5.0, 5.0, 10.0, 0.0 };
   int i;
    GLfloat colorSeleccion[4] = {0.8, 0.6, 0.8, 1.0 };
   
glPushMatrix();		// Apila la transformacion� geometrica actual

  // Fija el color de fondo a azul
  glClearColor(0,0,0.6,1);

  // Inicializa el buffer de color
  glClear( GL_COLOR_BUFFER_BIT  | GL_DEPTH_BUFFER_BIT );


  // Carga transformacion de visualizacion
    transformacionVisualizacion();
 

// Colocar aqui la luz si esta fija en la escena
	glLightfv( GL_LIGHT0, GL_POSITION, pos );	

//	ejes(30);

// Dibuja el suelo

 glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE,color[verde]);
  paralelepipedo(0.0,-0.5,0.0,0.0,0.0,0.0,200,200);



glPopMatrix(); // Desapila la transformaci� geom�rica

glutSwapBuffers();



}


/**
Procedimiento de fondo. Es llamado por glut cuando no hay eventos pendientes.
**/
void idle()
{


    
 gluiPostRedisplay();
 glutTimerFunc(30,idle,0);
}


