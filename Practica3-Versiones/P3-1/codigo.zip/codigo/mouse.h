/*

	C.A.D. 						Curso 2004-2005
	
	Dpto. Lenguajes y Sistemas Inform�icos
	E.T.S.I. Inform�ica
	Univ. de Granada

        mouse.c


*/

#ifndef __mouseH__ // Para evitar doble inclusion
#define __mouseH__



#ifndef __mouse__ // No esta compilando mouse

#define ambito extern

#else // Esta compilando  modelo

#define ambito

#endif



void clickRaton( int boton, int estado, int x, int y );


void RatonMovido( int x, int y );

#undef ambito

#endif

