/*

	C.A.D. 						Curso 2006-2007
	
	Dpto. Lenguajes y Sistemas Informaticos
	E.T.S.I. Informaica
	Univ. de Granada

        Modulo de transformacion de visualizacion del proyecto grua
	

*/

#include <GL/glut.h>
#include "glui.h"
#include "estructura.h"
#include "entradaTeclado.h"
#include "entradaMenu.h"
#include "visual.h"
#include "mouse.h"
#include "modelo.h"

#define  __iu__
#include "iu.h"


int nPalancas=3;

float Palanca[3]={0,0,0};

 GLubyte *pBytes;


void  creaIU(){
// ==================== Toolbar
 gluiCreateToolbar();
    gluiCreateMenu("Cajas", seleccionMenu );
   	gluiAddMenuEntry("Poner",PONERCAJAS);
   	gluiAddMenuEntry("Color",PINTARCAJA);
    	gluiAddMenuEntry("Rotar",ROTARCAJA);
     	gluiAddMenuEntry("Mover",MOVERCAJA);
    gluiCreateMenu("Vista", seleccionMenu );
  	gluiAddMenuEntry("3D",PASEAR);
	gluiAddMenuEntry("2D",DESDEARRIBA);
    gluiCreateMenu("Acciones", seleccionMenu );
   	gluiAddMenuEntry("Enganchar",ENGANCHAR); 
    	gluiAddMenuEntry("Desenganchar",DESENGANCHAR);
    gluiCreateMenu("Salir", seleccionMenu );
   	glutAddMenuEntry( "Confirmar", SALIR );

 gluiCreateIconMenu( 64); 
// cierra el toolbar y le asocia el botón izquierdo
// y crea el menú de iconos a la derecha de 64x64 pixels

     gluiAddIcon(); 
	glutDisplayFunc( drawSeleccionColor);
	glutMouseFunc( seleccionColor); 

    gluiAddIcon(); 
	glutDisplayFunc( DrawPalancas);
	glutMouseFunc( seleccionaPalancas); 
	glutMotionFunc( muevePalanca );
 
   gluiInput(entrada);

 gluiCreateCanvas();

}


/*  ------------- Carga textura   

*/


void drawSeleccionColor()
/*
	icon draw
*/
{ 
int k;
float x,y;

gluiClearColor();
  // Inicializa el buffer de color
glClear( GL_COLOR_BUFFER_BIT  | GL_DEPTH_BUFFER_BIT );

glDisable(GL_LIGHTING);

x=-0.8;
y=-0.8;
for(k=0;k<9;++k){
   glColor3f(color[k][0],color[k][1],color[k][2]);
   glBegin( GL_QUADS );{
      glVertex2f( x, y);
      glVertex2f( x+0.5, y);
      glVertex2f( x+0.5, y+0.5);
      glVertex2f( x, y+0.5); }
   glEnd();
   x+=0.55;
   if(x>0.5) {
	x=-0.8;
	y+=0.55;
	}
    }
 
if(gluiIsMouseOverIcon()) glui_iconFeedback(); 

glutSwapBuffers();
}


void seleccionColor( int boton, int estado, int x, int y)
{
int kx,ky,color;

if(boton== GLUT_LEFT_BUTTON && estado == GLUT_DOWN) {
	kx= (x-6)/18;
	ky= (y-6)/18;
	if(kx<0 || ky<0||kx>2||ky>2) return;
	color=kx+(2-ky)*3;

// ------------ Inserta codigo de asignación de color aqui

	gluiPostRedisplay();
	}
}



void entrada ( unsigned char *name)
{
printf("> %s \n",name);
}

/* ===============================
						Icono Palancas
*/

void DrawPalancas()
/*
	icon draw
*/
{
int i;
float x,r,dx;
float pos[4]={10,3,3,1};

gluiClearColor();
  // Inicializa el buffer de color
glClear( GL_COLOR_BUFFER_BIT  | GL_DEPTH_BUFFER_BIT );

glMatrixMode(GL_PROJECTION);
glLoadIdentity();
glOrtho(-1,1, -1,1,-4,10);
glMatrixMode(GL_MODELVIEW);
glLoadIdentity();
glEnable(GL_LIGHTING);
glColor3f(0,0,0);
dx= 0.6/(nPalancas+1);
glLightfv( GL_LIGHT0, GL_POSITION, pos );
glEnable( GL_LIGHT0);

glShadeModel(GL_SMOOTH);
for(i=0;i<nPalancas;++i){
	x= 2.0*(i+1)/(nPalancas+1.0)-1.0;
	r=45*Palanca[i];
//	r=-30+30*i;
	glPushMatrix();
	glTranslatef(x,0,0);
	glRotatef(r,1,0,0);
 	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, color[amarillo] );
	cilindro(0,0,0, 0,0,1,dx/3.0);
 	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, color[rojo] );
	glTranslatef(0,0,1);
	glutSolidSphere(dx,8,4);
	glPopMatrix();
	}
glShadeModel(GL_FLAT);
glDisable(GL_LIGHTING);
if(gluiIsMouseOverIcon()) glui_iconFeedback();
glutSwapBuffers();
}

int kold=-1;

void seleccionaPalancas( int boton, int estado, int x, int y)
{
int k;

if(boton== GLUT_LEFT_BUTTON && estado == GLUT_DOWN) {
	k= (x/64.0) * (nPalancas+1) -0.5;
	if(k<nPalancas && k>-1) {
		if(k==kold) Palanca[k]= (y-32)/32.0;
		kold=k;
		}
	else k=-1;

/*	if(k==0) 	// velocidad giro grua =Palanca[0];
	else if(k==1)  // velocidad pluma  =Palanca[1];
	else if(k==2) 	// velocidad cuerda =Palanca[2];
*/	
	glutPostRedisplay();
	gluiPostRedisplay();
	}
	else k=-1;
}

void muevePalanca( int x, int y)
{
int k;

k= (x/64.0) * (nPalancas+1) -0.5;
if(k<nPalancas && k>-1 && k==kold) {
	Palanca[k]= (y-32)/32.0;
	if(Palanca[k]>1) Palanca[k]= 1;
	if(Palanca[k]<-1) Palanca[k]= -1;
	if(Palanca[k]<0.1 && Palanca[k]>-0.1) Palanca[k]=0;
/*	if(k==0) // velocidad giro grua =Palanca[0];
	else if(k==1) // velocidad pluma  =Palanca[1];
	else if(k==2) // velocidad cuerda =Palanca[2];
*/
	glutPostRedisplay();
	gluiPostRedisplay();
	}
}

