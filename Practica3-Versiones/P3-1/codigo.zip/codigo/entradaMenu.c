/*

	C.A.D. 						Curso 2006-2007
	
	Dpto. Lenguajes y Sistemas Informaticos
	E.T.S.I. Informaica
	Univ. de Granada

        Modulo de entrada de menu del proyecto grua
	

*/
#define __entradaMenu__
#include <stdio.h>
#include <stdlib.h>
#include <GL/glut.h>                   // Libreria de utilidades de OpenGL
#include "visual.h"
#include "glui.h"
#include "entradaMenu.h"


// Nota: Los acentos han sido suprimidos en la documentacion por compatibilidad
// con las version usada de doxygen. Las letras ñ se han sustituido por "ny"


/** 

Este procedimiento es llamado por glut cuando ocurre un evento de seleccion de una 
opcion del menu. El parametro contiene el identificador de la opcion
 
 Cuando se anyanden opciones se debe anyadir un case en el switch para esa opcion.
 
 **/
 void seleccionMenu( int opcion )
{
   gluiSetCanvasWindow();
   gluiOutput( "");
   switch ( opcion )
   {   


   case PASEAR:
   	estadoMenu= paseando;
   	VISTA_PERSPECTIVA= 1; 
	glMatrixMode(GL_PROJECTION);
    	glLoadIdentity();
	fijaProyeccion();
	gluiOutput( "Vista 3D");
	break;
   case DESDEARRIBA: 
   	estadoMenu = vistaArriba; 
   	VISTA_PERSPECTIVA= 0; 
	glMatrixMode(GL_PROJECTION);
    	glLoadIdentity();
	fijaProyeccion();
	gluiOutput( "Vista 2D");
   	break;
   case SALIR:
   	  exit(0);      // Salir del programa
   }
	gluiPostRedisplay(); 	// Si se ha modificado algo que cambia el estado del
				// modelo se debe actualizar la pantalla
}


/** 

Crea el menu.

Este procedimiento debe llamarse para crear el menu glut (normalmente al inicializar el
programa).
 
Para anyadir opciones al menu anyadir una llamada glutAddMenuEntry e incluir valores del tipo enumerado en la declaracion de opciones_menu.

 **/
void CreaMenu()
{

   	menu = glutCreateMenu( seleccionMenu );

    	glutAddMenuEntry("Vista 2D",DESDEARRIBA);
    	glutAddMenuEntry("Pasear",PASEAR);
   	glutAddMenuEntry( "Exit", SALIR );           // opcion salir

   	glutAttachMenu( GLUT_RIGHT_BUTTON );	// Indica que el boton derecho abre el menu.

}

