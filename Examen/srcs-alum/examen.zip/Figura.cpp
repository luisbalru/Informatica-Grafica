

#include "Figura.hpp"
#include <vector>

Figura :: Figura()
{
  Construccion_Figura();
}
